<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<form action="savenu.php" method="post">
<center><h4><i class="icon-plus-sign icon-large"></i> Add Lab Stocks</h4></center>
<hr>
<div id="ac">
<span>Location : </span><input type="text" style="width:265px; height:30px;" name="name" required/><br>
<span>Description : </span><input type="text" style="width:265px; height:30px;" name="name2" required/><br>
<span>Sell price : </span><input type="text" style="width:265px; height:30px;" name="address" required/><br>
<span>Qty : </span><input type="text" style="width:265px; height:30px;" name="contact" required/><br>
<span>Units. : </span><input type="text" style="width:265px; height:30px;" name="cperson" /><br>
<span>Search Name : </span><input type="text" style="width:265px; height:30px;" name="name6" required/><br>
<span>Cost Price : </span><input type="text" style="width:265px; height:30px;" name="name3" required/><br>
<span>Re-order : </span><input type="text" style="width:265px; height:30px;" name="name4" /><br>
<span>Maximum : </span><input type="text" style="width:265px; height:30px;" name="name5" /><br>
<div style="float:right; margin-right:10px;">
<button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Save</button>
</div>
</div>
</form>