<footer class="main-footer">
    <p align ='center'><b><font size='80'>Medi+ | </font><font color ='blue' size ='80'>TRINITY CARE CENTER</font><b></p>
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
    <?
     $y =date('Y'); 
    ?>
    <strong>Copyright &copy; 2018 - <? echo $y;?> <ahref="http://paltechsystemconsultants.co.ke"><i>Paltech System</i></a></strong>
</footer>