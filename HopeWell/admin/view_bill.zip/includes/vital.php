<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left">
        <p><a><i class=" text-success"></i> <?php echo $username; ?></a></p><br>
          
        </div>
        <div class="pull-left info">
          <!--p><?php echo $user['firstname'].' '.$user['lastname']; ?></p-->
          <br><a><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>

      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">REPORTS</li>
        <li class=""><a href="home.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <li class="header">MANAGE</li>
        
        <li><a href="vital.php"><i class="fa fa-calendar"></i> <span>Vitals</span></a></li>
        
        <li><a href="#"><i class="fa fa-file-text"></i>In Patients </a></li>
        <!--li><a href="issue_to_patients.php"><i class="fa fa-suitcase"></i> Postings </a></li>
        
        <li><a href="reprints_invoice.php"><i class="fa fa-clock-o"></i> <span>Print Invoice</span></a></li>
        
        <li><a href="petty_cash.php"><i class="fa fa-files-o"></i> <span>Petty Cash</span></a></li>
        <li><a href="endofday_report2.php"><i class="fa fa-files-o"></i> <span>Daily Collection</span></a></li-->
        
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>