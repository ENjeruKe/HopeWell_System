<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left">
        <p><a><i class=" text-success"></i> <?php echo $username; ?></a></p><br>
          
        </div>
        <div class="pull-left info">
          <!--p><?php echo $user['firstname'].' '.$user['lastname']; ?></p-->
          <br><a><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>

      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">REPORTS</li>
        <li class=""><a href="home.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <li class="header">MANAGE</li>


<li><a href='mr.php'><i class='fa fa-hospital-o'></i> <span>Medical Report</span></a></li>

<li><ahref='gr.php'><i class='fa fa-hospital-o'></i> <span><font color ='white'><b>***General Reports***</b></font></span></a></li>


        <li><a href="repo_trial_balance.php"><i class="icon-list-alt icon-1x"></i>Trial Balance</a>  </li>             
			<li><a href="repo_profit_loss.php"><i class="icon-list-alt icon-1x"></i>Profit and Loss</a>                                     </li>
			<li><a href="repo_balance_sheet.php"><i class="icon-list-alt icon-1x"></i>Balance sheet</a>                                     </li>

			<li><a href="list_journals.php"><i class="icon-list-alt icon-1x"></i>Journal Voucher listing</a>                                     </li>

			<li><a href="list_bankings.php"><i class="icon-list-alt icon-1x"></i>List of Bankings</a>                                     </li>

			<li><a href="repo_gl_transactions.php"><i class="icon-list-alt icon-1x"></i>All Transactions by Account</a>                                    </li>


			<li><a href="repo_endofday_report_department.php"><i class="icon-list-alt icon-1x"></i>Cashier Daily summary</a>                                    </li>

			<li><a href="repo_list_final_invoices.php"><i class="icon-list-alt icon-1x"></i>All Receivable Invoices</a>                                    </li>

			<li><a href="repo_endofday_report_summary.php"><i class="icon-list-alt icon-1x"></i>Managerial Daily summary</a>                                    </li>
			<li><ahref="NHIF_claimform.php"><i class="icon-list-alt icon-1x"></i><font color ='white'><b>***Stocks and Procurement***</b></font></a>                                    </li>
			<li><a href="patients_talley2.php"><i class="icon-list-alt icon-1x"></i>All goods received</a>                                    </li>

                <li><a href="#"><i class="icon-user-md icon-1x"></i>All goods returned</a>       </li>
    

                <li><a href="#"><i class="icon-user-md icon-1x"></i>All LPOs</a>       </li>

                <li><a href="#"><i class="icon-user-md icon-1x"></i>All suppliers Invoices</a>       </li>

                <li><a href="#"><i class="icon-user-md icon-1x"></i>Inventory Listing and price</a>       </li>
    
                <li><a href="#"><i class="icon-user-md icon-1x"></i>Stocks Expiry report</a>       </li>

     <li><a href="#"><i class="icon-user-md icon-1x"></i>Stocks Variance report</a>       </li>

     <li><a href="#"><i class="icon-user-md icon-1x"></i>Stock movement by item</a>       </li>

     <li><a href="#"><i class="icon-user-md icon-1x"></i>Stock movement by store</a>       </li>



      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>