<html>
<!--title>Patients Register</title-->
<head>



<!--link rel="stylesheet" ref="http://www.w3schools.com/lib/w3.css"-->

<!--meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
<script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script-->



 <!--meta name="viewport" content="width=device-width, initial-scale=1">
  <!--link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script-->








<body>

<!--div class="w3-container w3-teal">
  <h1>Auto Receipt | <font color ='yellow'>Post Receipt</font></h1>
</div-->
<!--img src="img_car.jpg" alt="Car" style="width:100%"-->
<div class="w3-container" align ="right">

<script language="javascript" type="text/javascript">
<!--
var newwindow;
function popitup(url) {
	newwindow=window.open(url,'newwindow','height=570,width=850');
	if (window.focus) {newwindow.focus()}
	return false;
}

// -->
function popitup2(url) {
	newwindow=window.open(url,'newwindow','height=600,width=1000');
	if (window.focus) {newwindow.focus()}
	return false;
}

function popitup22(url) {
	newwindow=window.open(url,'newwindow','height=300,width=500');
	if (window.focus) {newwindow.focus()}
	return false;
}

function popitup3(url) {
	newwindow=window.open(url,'newwindow','height=600,width=1000');
	if (window.focus) {newwindow.focus()}
	return false;
}

function closeWin(url) {
    newwindow.close();   // Closes the new window
}


function myFunction() {
    var myWindow = window.open("patients_receipt.php", "", "width=1000, height=600");
}
</script>


<style>
#header {
    line-height:30px;
    background-color:white;
    height:20px;
    width:900px;
    float:left;
    padding:2px;	      
}

#hd2 {
    background-color:blue;
    color:white;
    text-align:left;
    padding:5px;
}

#nav {
    line-height:30px;
    background-color:#eeeeee;
    height:450px;
    width:100px;
    float:left;
    padding:5px;	      
}

#nav1 {
    line-height:20px;
    background-color:blue;
    color:white;
    height:20px;
    width:100px;
    float:left;
    padding:5px;	      
}

#nav2 {
    line-height:20px;
    background-color:blue;
    color:white;
    height:20px;
    width:200px;
    float:left;
    padding:5px;	      
}

#nav3 {
    line-height:20px;
    background-color:blue;
    color:white;
    height:20px;
    width:100px;
    float:left;
    padding:5px;	      
}

#nav4 {
    line-height:20px;
    background-color:blue;
    color:white;
    height:20px;
    width:150px;
    float:left;
    padding:5px;	      
}

#nav4a {
    line-height:20px;
    background-color:blue;
    color:white;
    height:20px;
    width:100px;
    float:left;
    padding:5px;	      
}

#nav5 {
    line-height:20px;
    background-color:blue;
    color:white;
    height:20px;
    width:75px;
    float:left;
    padding:5px;	      
}

#nav6 {
    line-height:20px;
    background-color:blue;
    color:white;
    height:20px;
    width:60px;
    float:left;
    padding:5px;	      
}
#nav7 {
    line-height:20px;
    background-color:blue;
    color:blue;
    height:20px;
    width:20px;
    float:left;
    padding:5px;	      
}

#nav8 {
    line-height:20px;
    background-color:blue;
    color:blue;
    height:20px;
    width:5px;
    float:left;
    padding:5px;	      
}

#section {
    height:350px;
    width:900px;
    float:left;
    padding:10px;	 	 
}
#footer {
    background-color:black;
    color:white;
    clear:both;
    text-align:center;
   padding:5px;	 	 
}
</style>
<!--p align ='right'><img src='chiromo-logo33.jpg' alt='statement' height='40' width='350'></p-->     



</head>








    







<!--div id="header" align ="center"-->
<input type="submit" name="Submit"  class="button" value="Post IP Receipts" onclick="return popitup('post_receipts2.php')"/>
<!--input type="submit" name="Submit"  class="button" value="List" onclick="return popitup2('list_patients.php')"/>
<input type="submit" name="Submit"  class="button" value="Attach Scan" onclick="return popitup22('upload_form.php')"/>
</div-->











<!--div id="section"-->
<OBJECT data="auto_receipt_select.php" type="text/html" style="margin: 0%; width: 100%; height: 450px; padding 0px; text-align:left;"></OBJECT>
<!--/div-->



</div>


<!--div id="footer">

Copyright � Paltech-systems.com | Affordable Connections - Call. +254-729-446-243
</div-->
</body>
</DIV>
</html>