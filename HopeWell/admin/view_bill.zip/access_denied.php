<html>
<body>
<?php
echo"<body background='images/access_denied.jpg'>";
?>
</body>
</html>
