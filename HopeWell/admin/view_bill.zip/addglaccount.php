<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<form action="saveglaccount.php" method="post">
<center><h4><i class="icon-plus-sign icon-large"></i> Add G/L Account</h4></center>
<hr>
<div id="ac">
<span>Name Name : </span><input type="text" style="width:265px; height:30px;" name="name" required/><br>
<span>Comment : </span><input type="text" style="width:265px; height:30px;" name="address" /><br>
<span>Type : </span><input type="text" style="width:265px; height:30px;" name="contact" /><br>
<span>OS Balance. : </span><input type="text" style="width:265px; height:30px;" name="cperson" /><br>
<!--span>Note : </span><textarea style="width:265px; height:80px;" name="note" /></textarea--><br>
<div style="float:right; margin-right:10px;">
<button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Save</button>
</div>
</div>
</form>