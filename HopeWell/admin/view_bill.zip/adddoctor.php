<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<form action="savedoctor.php" method="post">
<center><h4><i class="icon-plus-sign icon-large"></i> Add Doctor</h4></center>
<hr>
<div id="ac">
<span>Doctors Name : </span><input type="text" style="width:265px; height:30px;" name="name" required/><br>
<span>Contacts : </span><input type="text" style="width:265px; height:30px;" name="address" /><br>
<span>Address : </span><input type="text" style="width:265px; height:30px;" name="contact" /><br>
<span>Balance : </span><input type="text" style="width:265px; height:30px;" name="cperson" /><br>
<span>Department : </span><textarea style="width:265px; height:50px;" name="note" /></textarea><br>
<div style="float:right; margin-right:10px;">
<button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Save</button>
</div>
</div>
</form>