<?php
session_start();
 require('open_database.php');

?>






<script language="JavaScript" src="popups/pop-up.js"></script>
<link rel=StyleSheet href="popups/pop-upstyle.css" type="text/css" media="screen">
</head>
<!--link rel=StyleSheet href="popups/pop-upstyle.css" type="text/css" media="screen">
<script language="JavaScript" src="popups/debtors-pop-up.js"></script-->

	<meta charset="utf-8" />
	<title>Patient Register - Formoid contact form</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">



<?php
 $branch     = $_SESSION['company']; 
 $date2 = date('y-m-d');
 $date1 = date('y-m-d');



 if (isset($_GET['print'])){

   $date1  = $_GET['date1'];
   $date2  = $_GET['date2'];
 //  $date2 = $date2.' 24:60:60';


   $query= "SELECT * FROM companyfile" or die(mysql_error());
   $result =mysql_query($query) or die(mysql_error());
   $num =mysql_numrows($result) or die(mysql_error());
   $tot =0;



   $i = 0;
   $SQL = "select * FROM companyfile" ;
   $hasil=mysql_query($SQL, $connect);
   $id = 0;
   $nRecord = 1;
   $No = $nRecord;

   while ($row=mysql_fetch_array($hasil)) 
   {         
      $company     = mysql_result($result,$i,"company");  
      $address1    = mysql_result($result,$i,"address1");   
      $address2    = mysql_result($result,$i,"address2");   
      $address3    = mysql_result($result,$i,"address3");   
   }
   echo"<font size ='2'>";
   echo"<table width ='500'>";      
   echo"<tr><td align ='left'><b>$company</b></td></tr>";
   echo"<tr><td align ='left'><b>$address1</b></td></tr>";
   echo"<tr><td align ='left'><b>$address2</b></td></tr>";
   echo"<tr><td align ='left'><b>$address3</b></td></tr>";
   echo"</table><br>";

   echo"<h4>MONTHLY LABORATORY REPORT <img src='space.jpg' style='width:20px;height:2px;'>"."Dated from: ".$date1."<img src='space.jpg' style='width:20px;height:2px;'>"."To :".$date2;
echo"</h4>";
//   echo"Dated from: ".$date1."<img src='space.jpg' style='width:20px;height:2px;'>"."To :".$date2;

   //echo"<img src='ico/black.jpg' style='width:500px;height:1px;'><br>";





$today = date('y-m-d');
$mdate =date('y-m-d');
//$date1  = $_GET['date1'];
//$date2  = $_GET['date2'];

$query  = "select * FROM ranges WHERE date >='$date1' AND date <= '$date2' ORDER BY date,invoice_no" ;
$result =mysql_query($query);
$num =mysql_numrows($result);





$tot =0;
$i = 0;
                                                         






?>
<table width ='100%'>
<tr>
<th bgcolor ='black' width ='100'><font color ='white'>Date</th>
<th bgcolor ='black' width ='350' align ='left'><font color ='white'>Patient</th>
<th bgcolor ='black' width ='50' align ='left'><font color ='white'>Ref.No..:</th>
<th bgcolor ='black' width ='200' align ='left'><font color ='white'>Test Description</th>
<th bgcolor ='black' width ='100'><font color ='white'>Count</th>
<th bgcolor ='black' width ='100'><font color ='white'>Tot. Count</th>
</tr>
<hr>

<?php

$query = "SELECT * FROM ranges WHERE date >='$date1' AND date <= '$date2' GROUP BY description"; 	 
$result = mysql_query($query) or die(mysql_error());
while ($row=mysql_fetch_array($result)) {
      $test = $row['description'];
//echo 'Test'.$test;
    $SQL ="select * FROM ranges WHERE description ='$test' and date >='$date1' AND date <= '$date2' ORDER BY date" ;   
       $hasil=mysql_query($SQL, $connect);
       $id = 0;
       $nRecord = 1;
       $No = $nRecord;
       $debit  = 0;
       $credit = 0;
       $tot_bill = 0;
       $tot_paid = 0;
       $docno ='';
       echo "<table width ='100%'>";
       $paid =0;
    while ($row=mysql_fetch_array($hasil)) {
         echo "<tr>";
       echo "<td width ='100'>" . $row['date'] . "</td>";
       echo "<td width ='350'>" . $row['gl_account'] . "</td>";
      $_SESSION['ref_no'] =$row['invoice_no'];  
      $aa =$row['invoice_no'];        
      $aa5=$row['description'];  
      $ggg=1;
      $update2 =$ggg;  
      
      $paid = $update2;
      $aa7=$row['date'];        
      echo "<td width ='50'>$aa</td>";
       echo "<td width ='200'>" . $row['description'] . "</td>";
       echo "<td align ='right' width ='100'>" . number_format($ggg) . "</td>";
       $tot_bill = $tot_bill+$paid;
       $update2 = number_format($update2);
       $rate = number_format($paid);
       $tot_bill2 = number_format($tot_bill);
       echo "<td align ='right' width ='100'>" . $tot_bill2. "</td>";
       echo "</tr>";

                }
    
      echo"</table>";
      echo"<hr>";
      echo"<table border='0' width ='100%'>";   
      $tot_bill = number_format($tot_bill);
      $tot_paid = number_format($tot_paid);
      $tot = number_format($tot);
      echo"<tr>";
      echo"<td width ='320' align ='left'>";
      echo"</td>";      
      echo"<td width ='300'>";
      //echo"</td>";      
      //echo"</b></td>";      
      //echo"</td>";      
      //echo"<td width ='200' align ='center'>";      
      //echo"Total";      
      echo"</td>";          
      echo"<td width ='70' align ='right'><b>$tot_bill2</b></td>";      
      echo"</tr>";   
      //echo"</font>";
      echo"</table>";
}
 }else{      
?>









<!DOCTYPE html>
<html>
<title>HMIS Global</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!--link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css"-->
<head>
<body>
<div class="w3-container w3-teal">
  <h1>Monthly Laboratory Report | <font color ='red'></font></h1>
</div>
<!--img src="img_car.jpg" alt="Car" style="width:100%"-->
<div class="w3-container">
<p align ='right'><img src='chiromo-logo33.jpg' alt='statement' height='40' width='350'></p>

<style type="text/css">
html, 
body {
height: 100%;
}

body {
background-image: url(images/backgrounds.jpg);
background-repeat: no-repeat;
background-size: cover;
}
</style>











<?php
  echo"<br>";
  echo"<form action ='lab_counts.php' method ='GET'>";
  echo"<table><tr><td width ='50'>From Date:</td><td><input type='date' name='date1' value ='$date1' size='12' ></td></tr>";
  echo"<tr><td width='50'>To Date:</td><td><input type='date' name='date2' value ='$date2' size='12'></td><tr>";
  echo"<tr><td width='50'><input type='submit' name='print'  class='button' value='Print Report'></td><td></td></tr>";
echo"</FORM>";


$today = date('y/m/d');


?>
<table width ='20' border='0' height='220'></table>

</div>
<div class="w3-container w3-teal">
  <p>Developed by Paltech System Consultants | E-mail: info@hmisglobal.com</p>
</div>
</body>
</head>
<script language="JavaScript" src="popups/pop-up.js"></script>
<link rel=StyleSheet href="popups/pop-upstyle.css" type="text/css" media="screen">
</head>
<!--link rel=StyleSheet href="popups/pop-upstyle.css" type="text/css" media="screen">
<script language="JavaScript" src="popups/debtors-pop-up.js"></script-->

	<meta charset="utf-8" />
	<title>Patient Register - Formoid contact form</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</html>
<?php
}
?>